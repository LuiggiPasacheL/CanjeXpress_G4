class User:
    def __init__(self, id, username, password, points):
        self.id = id
        self.username = username
        self.password = password
        self.points = points
